package com.nseindia.b2.employee.database;

import com.nseindia.b2.employee.model.Leave;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface LeaveRepository extends CrudRepository<Leave, Long> {
    @Query("from Leave l inner join l.employee as e where e.id = :employeeId and l.approvalStatus = com.nseindia.b2.employee.model.ApprovalStatus.PENDING")
    List<Leave> findAllPendingLeaveForEmployee(Long employeeId);
}
