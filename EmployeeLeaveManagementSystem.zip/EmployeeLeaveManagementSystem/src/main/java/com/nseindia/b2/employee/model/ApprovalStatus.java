package com.nseindia.b2.employee.model;


public enum ApprovalStatus {
    PENDING,
    APPROVED,
    DENIED
}
